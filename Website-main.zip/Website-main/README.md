<div align="center">

# ![Forza Mods](.github/assets/icon.png)

_Browse and share mods for Forza Horizon 5._

<img src=".github/assets/screenshot.png">

</div>

<br/>
<br/>
<br/>

<div align="center">

![Next JS](https://img.shields.io/badge/Next-black?style=for-the-badge&logo=next.js&logoColor=white) ![DaisyUI](https://img.shields.io/badge/daisyui-5A0EF8?style=for-the-badge&logo=daisyui&logoColor=white)

</div>

# ✨ Features

- User Profiles
- Mod Browser
- Downloading and uploading mods
- Submitting ideas

# 🔧 Credits

- Web Frontend and Backend: [d4vss](https://github.com/d4vss)
- Images: [szaaamerik](https://github.com/szaaamerik)
- Troubleshooting documentation: [Veki28](https://github.com/Veki28)